#include <jni.h>
#include <string.h>

extern JNIEXPORT jstring JNICALL
Java_com_ssrlive_ssrdroid_MainActivity_stringFromJNI(JNIEnv *env, jobject This) {
    return (*env)->NewStringUTF(env, "Hello from Native code");
}
