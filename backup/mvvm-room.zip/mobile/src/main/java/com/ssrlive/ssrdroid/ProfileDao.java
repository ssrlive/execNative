package com.ssrlive.ssrdroid;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ProfileDao {

    @Insert
    void insert(Profile... profiles);

    @Update
    void update(Profile... profiles);

    @Delete
    void delete(Profile... profiles);

    @Query("DELETE FROM profile_table")
    void deleteAllProfiles();

    @Query("SELECT * FROM profile_table ORDER BY priority_column DESC")
    LiveData<List<Profile> > getAllProfiles();
}
