package com.ssrlive.ssrdroid;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {Profile.class}, version = 1, exportSchema = false)
public abstract class ProfileDatabase extends RoomDatabase {
    private static ProfileDatabase instance;
    public abstract ProfileDao profileDao();

    static synchronized ProfileDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(), ProfileDatabase.class, "ssr_droid_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsychTask(instance).execute();
        }
    };

    private static class PopulateDbAsychTask extends AsyncTask<Void, Void, Void> {
        private ProfileDao profileDao;

        PopulateDbAsychTask(ProfileDatabase db) {
            profileDao = db.profileDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            profileDao.insert(new Profile("good idea", "good idea DESCRIPTION1", 1));
            profileDao.insert(new Profile("absolute", "absolute DESCRIPTION1", 2));
            profileDao.insert(new Profile("Hotdog", "Hotdog DESCRIPTION1", 3));
            return null;
        }
    }
}
