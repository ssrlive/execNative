package com.ssrlive.ssrdroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final int ADD_PROFILE_REQUEST = 1;
    public static final int EDIT_PROFILE_REQUEST = 2;

    private ProfileViewModel profileViewModel;

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Example of a call to a native method
        //TextView tv = findViewById(R.id.sample_text);
        //tv.setText(stringFromJNI());

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final ProfileAdapter adapter = new ProfileAdapter();
        recyclerView.setAdapter(adapter);

        profileViewModel = ViewModelProviders.of(this).get(ProfileViewModel.class);
        profileViewModel.getAllProfiles().observe(this, new Observer<List<Profile>>() {
            @Override
            public void onChanged(List<Profile> profiles) {
                adapter.submitList(profiles);
            }
        });

        FloatingActionButton buttonAddProfile = findViewById(R.id.button_add_profile);
        buttonAddProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
                startActivityForResult(intent, ADD_PROFILE_REQUEST);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                profileViewModel.delete(adapter.getProfileAt(viewHolder.getAdapterPosition()));
                Toast.makeText(MainActivity.this, "Profile deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);

        adapter.setOnItemClickListener(new ProfileAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Profile profile) {
                Intent intent = new Intent(MainActivity.this, EditProfileActivity.class);
                intent.putExtra(EditProfileActivity.EXTRA_TITLE, profile.getTitle());
                intent.putExtra(EditProfileActivity.EXTRA_DESCRIPTION, profile.getDescription());
                intent.putExtra(EditProfileActivity.EXTRA_PRIORITY, profile.getPriority());
                intent.putExtra(EditProfileActivity.EXTRA_ID, profile.getId());
                startActivityForResult(intent, EDIT_PROFILE_REQUEST);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item_delete_all:
                profileViewModel.deleteAllProfiles();
                Toast.makeText(this, "All profiles deleted", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_PROFILE_REQUEST && resultCode==RESULT_OK) {
            assert data != null;
            String title = data.getStringExtra(EditProfileActivity.EXTRA_TITLE);
            String description = data.getStringExtra(EditProfileActivity.EXTRA_DESCRIPTION);
            int priority = data.getIntExtra(EditProfileActivity.EXTRA_PRIORITY, 1);

            Profile profile = new Profile(title, description, priority);
            profileViewModel.insert(profile);
            Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show();
        } else if (requestCode == EDIT_PROFILE_REQUEST && resultCode==RESULT_OK) {
            assert data != null;
            int id = data.getIntExtra(EditProfileActivity.EXTRA_ID, -1);
            if(id == -1) {
                Toast.makeText(this, "Profile can't be updated", Toast.LENGTH_SHORT).show();
                return;
            }
            String title = data.getStringExtra(EditProfileActivity.EXTRA_TITLE);
            String description = data.getStringExtra(EditProfileActivity.EXTRA_DESCRIPTION);
            int priority = data.getIntExtra(EditProfileActivity.EXTRA_PRIORITY, 1);

            Profile profile = new Profile(title, description, priority);
            profile.setId(id);
            profileViewModel.update(profile);
            Toast.makeText(this, "Profile Updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Profile not saved", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
