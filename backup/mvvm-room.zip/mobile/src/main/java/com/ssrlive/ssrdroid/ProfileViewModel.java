package com.ssrlive.ssrdroid;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ProfileViewModel extends AndroidViewModel {
    private ProfileRepository repository;
    private LiveData<List<Profile> > allProfiles;

    public ProfileViewModel(@NonNull Application application) {
        super(application);
        repository = new ProfileRepository(application);
        allProfiles = repository.getAllProfiles();
    }

    void insert(Profile... profiles) {
        repository.insert(profiles);
    }

    void update(Profile... profiles) {
        repository.update(profiles);
    }

    void delete(Profile... profiles) {
        repository.delete(profiles);
    }

    void deleteAllProfiles() {
        repository.deleteAllProfiles();
    }

    LiveData<List<Profile> > getAllProfiles() {
        return allProfiles;
    }
}
