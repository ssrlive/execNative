package com.ssrlive.ssrdroid;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

class ProfileRepository {
    private ProfileDao profileDao;
    private LiveData<List<Profile> > allProfiles;

    ProfileRepository(Application application) {
        ProfileDatabase database = ProfileDatabase.getInstance(application);
        profileDao = database.profileDao();
        allProfiles = profileDao.getAllProfiles();
    }

    void insert(Profile... profiles) {
        new InsertProfileAsyncTask(profileDao).execute(profiles);
    }

    void update(Profile... profiles) {
        new UpdateProfileAsyncTask(profileDao).execute(profiles);
    }

    void delete(Profile... profiles) {
        new DeleteProfileAsyncTask(profileDao).execute(profiles);
    }

    void deleteAllProfiles() {
        new DeleteAllProfilesAsyncTask(profileDao).execute();
    }

    LiveData<List<Profile> > getAllProfiles() {
        return allProfiles;
    }

    public static class InsertProfileAsyncTask extends AsyncTask<Profile, Void, Void> {
        private ProfileDao profileDao;

        private InsertProfileAsyncTask(ProfileDao profileDao) {
            this.profileDao = profileDao;
        }

        @Override
        protected Void doInBackground(Profile... profiles) {
            profileDao.insert(profiles);
            return null;
        }
    }

    public static class UpdateProfileAsyncTask extends AsyncTask<Profile, Void, Void> {
        private ProfileDao profileDao;

        private UpdateProfileAsyncTask(ProfileDao profileDao) {
            this.profileDao = profileDao;
        }

        @Override
        protected Void doInBackground(Profile... profiles) {
            profileDao.update(profiles);
            return null;
        }
    }

    public static class DeleteProfileAsyncTask extends AsyncTask<Profile, Void, Void> {
        private ProfileDao profileDao;

        private DeleteProfileAsyncTask(ProfileDao profileDao) {
            this.profileDao = profileDao;
        }

        @Override
        protected Void doInBackground(Profile... profiles) {
            profileDao.delete(profiles);
            return null;
        }
    }

    public static class DeleteAllProfilesAsyncTask extends AsyncTask<Void, Void, Void> {
        private ProfileDao profileDao;

        private DeleteAllProfilesAsyncTask(ProfileDao profileDao) {
            this.profileDao = profileDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            profileDao.deleteAllProfiles();
            return null;
        }
    }
}
