//
// How to compile for Windows on Linux with gcc/g++?
// https://stackoverflow.com/questions/2033997/how-to-compile-for-windows-on-linux-with-gcc-g
//

apt install mingw-w64

//
// http://www.mingw.org/wiki/sampledll
//

x86_64-w64-mingw32-g++ -c -DBUILDING_EXAMPLE_DLL example_dll.cpp
x86_64-w64-mingw32-g++ -shared -o example_dll.dll example_dll.o -Wl,--out-implib,libexample_dll.a

x86_64-w64-mingw32-g++ -c example_exe.cpp
x86_64-w64-mingw32-g++ -o example_exe.exe example_exe.o -L. -lexample_dll
x86_64-w64-mingw32-g++ -o example_exe.exe example_exe.o example_dll.dll
