package com.ssrlive.words;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class WordsFragment extends Fragment {
    private WordViewModel wordViewModel;
    private RecyclerView recyclerView;
    private MyAdapter myAdapter1, myAdapter2;
    private LiveData<List<Word> > filteredWords;
    private List<Word> wordsCache;
    private Observer<List<Word>> observer;
    private LifecycleOwner lifecycleOwner;
    private static final String VIEW_TYPE_SP = "view_type";
    private static final String USING_CARD_VIEW = "using_card_view";
    private boolean undoAction;
    private DividerItemDecoration dividerItemDecoration;

    FloatingActionButton floatingActionButton;


    public WordsFragment() {
        // Required empty public constructor
        setHasOptionsMenu(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_words, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final FragmentActivity fragmentActivity = requireActivity();
        wordViewModel = ViewModelProviders.of(fragmentActivity).get(WordViewModel.class);

        recyclerView = fragmentActivity.findViewById(R.id.recyclerView);
        myAdapter1 = new MyAdapter(false, wordViewModel);
        myAdapter2 = new MyAdapter(true, wordViewModel);
        recyclerView.setLayoutManager(new LinearLayoutManager(fragmentActivity));
        recyclerView.setItemAnimator(new DefaultItemAnimator() {
            @Override
            public void onAnimationFinished(@NonNull RecyclerView.ViewHolder viewHolder) {
                super.onAnimationFinished(viewHolder);
                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                if (linearLayoutManager != null) {
                    int firstPos = linearLayoutManager.findFirstVisibleItemPosition();
                    int lastPos = linearLayoutManager.findLastVisibleItemPosition();
                    for (int i=firstPos; i<=lastPos; ++i) {
                        MyAdapter.MyViewHolder holder = (MyAdapter.MyViewHolder) recyclerView.findViewHolderForAdapterPosition(i);
                        if (holder != null) {
                            holder.textViewNumber.setText(String.valueOf(i + 1));
                        }
                    }
                }
            }
        });

        SharedPreferences sp = requireActivity().getSharedPreferences(VIEW_TYPE_SP, Context.MODE_PRIVATE);
        boolean isCardView = sp.getBoolean(USING_CARD_VIEW, false);
        recyclerView.setAdapter(isCardView ? myAdapter2 : myAdapter1);

        dividerItemDecoration = new DividerItemDecoration(fragmentActivity, DividerItemDecoration.VERTICAL);
        if (!isCardView) {
            recyclerView.addItemDecoration(dividerItemDecoration);
        }

        observer = new Observer<List<Word>>() {
            @Override
            public void onChanged(List<Word> words) {
                wordsCache = words;
                int tmp1 = myAdapter1.getItemCount();
                if (tmp1 != words.size()) {
                    myAdapter1.submitList(words);
                }
                int tmp2 = myAdapter2.getItemCount();
                if (tmp2 != words.size()) {
                    myAdapter2.submitList(words);
                    if (tmp2 < words.size() && !undoAction) {
                        recyclerView.smoothScrollBy(0, -200);
                    }
                    undoAction = false;
                }
            }
        };

        lifecycleOwner = getViewLifecycleOwner();

        filteredWords = wordViewModel.getAllWords();
        filteredWords.observe(lifecycleOwner, observer);

        floatingActionButton = fragmentActivity.findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavController controller = Navigation.findNavController(v);
                controller.navigate(R.id.action_wordsFragment_to_addFragment);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.START | ItemTouchHelper.END) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                final Word word = wordsCache.get(viewHolder.getAdapterPosition());
                wordViewModel.deleteWords(word);

                Snackbar.make(fragmentActivity.findViewById(R.id.wordsFragmentView), "A word item deleted", Snackbar.LENGTH_SHORT)
                        .setAction("Undo", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                wordViewModel.insertWords(word);
                                undoAction = true;
                            }
                        })
                        .show();
            }

            Drawable icon = ContextCompat.getDrawable(fragmentActivity, R.drawable.ic_delete_forever_black_24dp);
            Drawable background = new ColorDrawable(Color.LTGRAY);
            @Override
            public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
                View itemView = viewHolder.itemView;
                int iconMargin = (itemView.getHeight() - icon.getIntrinsicHeight()) / 2;
                int iconLeft,iconRight,iconTop,iconBottom;
                int backTop,backBottom,backLeft,backRight;
                backTop = itemView.getTop();
                backBottom = itemView.getBottom();
                iconTop = itemView.getTop() + (itemView.getHeight() - icon.getIntrinsicHeight()) /2;
                iconBottom = iconTop + icon.getIntrinsicHeight();
                if (dX > 0) {
                    backLeft = itemView.getLeft();
                    backRight = itemView.getLeft() + (int)dX;
                    background.setBounds(backLeft,backTop,backRight,backBottom);
                    iconLeft = itemView.getLeft() + iconMargin ;
                    iconRight = iconLeft + icon.getIntrinsicWidth();
                    icon.setBounds(iconLeft,iconTop,iconRight,iconBottom);
                } else if (dX < 0){
                    backRight = itemView.getRight();
                    backLeft = itemView.getRight() + (int)dX;
                    background.setBounds(backLeft,backTop,backRight,backBottom);
                    iconRight = itemView.getRight()  - iconMargin;
                    iconLeft = iconRight - icon.getIntrinsicWidth();
                    icon.setBounds(iconLeft,iconTop,iconRight,iconBottom);
                } else {
                    background.setBounds(0,0,0,0);
                    icon.setBounds(0,0,0,0);
                }
                background.draw(c);
                icon.draw(c);
            }
        }).attachToRecyclerView(recyclerView);
    }

    @Override
    public void onResume() {
        super.onResume();
        //InputMethodManager imm = (InputMethodManager) requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        //imm.hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main_menu, menu);
        SearchView searchView = (SearchView) menu.findItem(R.id.app_bar_search).getActionView();
        searchView.setMaxWidth(getView().getWidth() * 5 / 8);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filteredWords.removeObservers(lifecycleOwner);
                filteredWords = wordViewModel.findWordsWithPattern(newText.trim());
                filteredWords.observe(lifecycleOwner, observer);
                return true;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.clearData:
                AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
                builder.setTitle("Clear Data");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        wordViewModel.deleteAllWords();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.create();
                builder.show();
                break;

            case R.id.switchView:
                SharedPreferences sp = requireActivity().getSharedPreferences(VIEW_TYPE_SP, Context.MODE_PRIVATE);
                boolean isCardView = sp.getBoolean(USING_CARD_VIEW, false);
                isCardView = !isCardView;
                SharedPreferences.Editor editor = sp.edit();
                editor.putBoolean(USING_CARD_VIEW, isCardView);
                editor.apply();

                recyclerView.setAdapter(isCardView ? myAdapter2 : myAdapter1);
                if (!isCardView) {
                    recyclerView.addItemDecoration(dividerItemDecoration);
                } else {
                    recyclerView.removeItemDecoration(dividerItemDecoration);
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
