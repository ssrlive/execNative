package com.ssrlive.words;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.inputmethod.InputMethodManager;

public class MainActivity extends AppCompatActivity {
    NavController controller;
    InputMethodManager imm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        controller = Navigation.findNavController(findViewById(R.id.fragment));
        NavigationUI.setupActionBarWithNavController(this, controller);
        imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    /*
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        controller.navigateUp();
    }
     */

    @Override
    public boolean onSupportNavigateUp() {
        imm.hideSoftInputFromWindow(findViewById(R.id.fragment).getWindowToken(), 0);

        controller.navigateUp();
        return super.onSupportNavigateUp();
    }
}
